Open MavenMarket_Report.pbip in Power BI Desktop. Set the DataFolder parameter to the folder holding the 8 CSV files.
